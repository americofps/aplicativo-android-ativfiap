package com.example.consumoapi.model;

data class Coordenadas(

    val lat: String="",
    val lon: String=""
)